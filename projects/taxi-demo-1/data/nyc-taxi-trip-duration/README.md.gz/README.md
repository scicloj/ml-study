Source: https://www.kaggle.com/c/nyc-taxi-trip-duration/data
